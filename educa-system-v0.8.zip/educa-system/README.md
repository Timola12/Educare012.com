# EDUCA SYSTEM — v0.6 Academic Management

EDUCA SYSTEM is a multi-school school-management SaaS for Kenyan primary and secondary schools. School onboarding remains restricted to the Platform Owner. Schools cannot self-register.

## Current release: v0.6

Includes the v0.5 school-administration foundation plus the academic tools listed below.

## What's new in v0.5

- Platform Owner can create school administrator accounts for a selected school.
- Initial administrator passwords are chosen by the Platform Owner and stored as bcrypt hashes.
- School administrators are required to change their initial password at first sign-in.
- A separate responsive School Administrator Portal is available at `school-portal.html`.
- School administrators can create classes/streams, admit students, view their student register and record daily attendance.
- School API queries are scoped to the authenticated administrator's `school_id`; student/class and attendance foreign keys also enforce school consistency.
- School administrator access is denied when the school is suspended or has no currently active subscription.

## Project structure

- `index.html` — Platform Owner console.
- `school-portal.html` — School Administrator Portal.
- `manifest.webmanifest` and `sw.js` — installable owner-console web app foundation.
- `backend/` — Node.js/Express API and PostgreSQL migrations.

## Backend setup

Requirements: Node.js 20+ and PostgreSQL 15+.

```bash
cd backend
cp .env.example .env
# Edit .env: DATABASE_URL, JWT_SECRET (32+ random characters), CORS_ORIGIN
npm install
psql "$DATABASE_URL" -f migrations/001_initial.sql
psql "$DATABASE_URL" -f migrations/002_school_admin_portal.sql
psql "$DATABASE_URL" -f migrations/003_academic_management.sql
npm run create-owner
npm run dev
```

The owner-creation script prompts for the Platform Owner's name, email and private password. There is no built-in production password.

## Run the web pages

From the project root, in another terminal:

```bash
python -m http.server 8000
```

- Owner console: `http://localhost:8000/`
- School administrator portal: `http://localhost:8000/school-portal.html`
- API health check: `http://localhost:4000/api/health`

Set the API URL on either sign-in page. Both pages can use the same origin and API. For a hosted setup, configure `CORS_ORIGIN` to the exact HTTPS website origin and serve the API over HTTPS.

## School administrator onboarding

1. Sign in to the Platform Owner console.
2. Register a school and assign a subscription whose dates include today.
3. Open **School administrators** and create an account for that school. Supply a unique email and a strong initial password (at least 12 characters).
4. Share the initial password privately with the administrator. The system requires them to change it after signing in. No email/SMS invitation delivery is implemented yet.
5. The administrator signs in at `/school-portal.html`, changes the temporary password, creates classes, admits students and records attendance.

## School administration API routes added in v0.5

Owner-only:
- `GET /api/owner/school-admins`
- `POST /api/owner/schools/:id/admin`

Authenticated account:
- `POST /api/auth/change-password`

School Administrator-only (all school data scoped by `req.user.school_id`):
- `GET /api/school/profile`
- `GET /api/school/classes`
- `POST /api/school/classes`
- `GET /api/school/students`
- `POST /api/school/students`
- `GET /api/school/attendance?date=YYYY-MM-DD`
- `POST /api/school/attendance`

## Important limitations and production requirements

This is a development build, not a production-certified school information system. The portal currently covers classes, student admission/register, attendance, subject setup, assessment/exam setup, marks entry and basic printable score reports. Parent/student accounts, teacher self-service sign-in/workspace, official CBC achievement-level calculations, KNEC grading, class rankings, weighted averages, fees, payroll, library, transport, SMS and automated M-Pesa are not implemented in this release. The payment number supplied for EDUCA SYSTEM subscriptions is **+254 796 304 807**; payment collection and automatic M-Pesa verification are not enabled.

Before real learner data is entered or the service is publicly launched, complete: secure refresh-token rotation and session revocation; MFA for Platform Owner; password reset and invitation delivery; rate limiting on all sensitive endpoints; strict tenant isolation tests and preferably PostgreSQL row-level security with a least-privilege database role; encrypted backups and restore drills; audit logging for school-user activity; privacy/retention controls; HTTPS and secrets management; monitoring; accessibility and browser/device testing; independent security review; and review against Kenya's Data Protection Act and applicable education-sector requirements.

Never use the sample/demo learner records from older browser prototypes. This cloud portal does not import them.


## v0.6 — Academic management

Apply the additional migration after migrations 001 and 002 (the backend setup commands above include it):

```bash
psql "$DATABASE_URL" -f migrations/003_academic_management.sql
```

The School Portal now includes an **Academics** workspace. A school administrator can create subjects tagged CBC, 8-4-4 or General; create class-specific formative, summative and examination assessments by academic year and term; enter/update marks with score-limit checks; and open a printable learner report that can be saved as PDF through the browser print dialog. Curriculum labels are configurable per subject/assessment; the software does not assume that every Kenyan school follows the same pathway or grading rules.

### Academic API routes (School Administrator; tenant-scoped)
- `GET/POST /api/school/subjects`
- `GET/POST /api/school/assessments`
- `GET /api/school/assessments/:id/marks`
- `POST /api/school/assessments/:id/marks`
- `GET /api/school/students/:id/report`

Marks are restricted to active students in the assessment's class. The report currently lists entered scores and teacher comments; it does not yet calculate official CBC achievement levels, KNEC grades, class positions, averages across weighted assessments, or Ministry-approved report-card templates. Teacher-specific accounts and assignment management are added in v0.7.

## Updated setup sequence
Run migrations in order: `001_initial.sql`, `002_school_admin_portal.sql`, `003_academic_management.sql`, then `004_teacher_management.sql`. The academic module is included in the same school portal URL.

This release has passed static JavaScript syntax checks only. It has not been run against a provisioned PostgreSQL database or independently security-tested. Do not enter real learner data until database migration, tenant-isolation tests, backups, privacy controls and production security review have been completed.


## v0.7 — Teacher management

Apply `004_teacher_management.sql` after migrations 001–003. The School Portal now has a **Teachers** workspace for school administrators to create teacher accounts (with a forced password change flag), activate/deactivate teacher accounts, assign teachers to classes and subjects for a matching academic year, remove assignments, and record daily teacher attendance (present, absent, late or leave).

### Teacher management API (School Administrator; tenant-scoped)
- `GET/POST /api/school/teachers`
- `PATCH /api/school/teachers/:id/status`
- `GET/POST /api/school/teacher-assignments`
- `DELETE /api/school/teacher-assignments/:id`
- `GET/POST /api/school/teacher-attendance`

Teacher records and all assignments are scoped to the administrator's school. Composite database constraints prevent assignments and attendance from linking a teacher, class or subject from another school. The current release does not yet provide a teacher self-service sign-in/workspace or teacher mark-entry permission; teacher accounts are provisioned for the next milestone.

## Updated migration sequence

```bash
psql "$DATABASE_URL" -f migrations/001_initial.sql
psql "$DATABASE_URL" -f migrations/002_school_admin_portal.sql
psql "$DATABASE_URL" -f migrations/003_academic_management.sql
psql "$DATABASE_URL" -f migrations/004_teacher_management.sql
```

Static syntax checks passed for the backend and inline frontend scripts. PostgreSQL migrations and runtime API flows have not been integration-tested against a live database.


## v0.8 — Teacher Portal and mark review

New in this release:
- Dedicated teacher sign-in at `teacher-portal.html`; teacher accounts are still provisioned by the School Administrator.
- Teachers see only their own assigned class/subject combinations and matching assessments.
- Teachers enter learner marks, save drafts, and submit complete mark sheets for administrator review. Scores are checked against the assessment maximum and learners must be active members of the assigned class.
- Submitted and approved mark sheets are locked for teacher editing. School Administrators can approve or return submitted sheets with a review note; returned sheets can be corrected and resubmitted.
- Added school-scoped submission workflow table and review endpoints.

### v0.8 migration
Run all previous migrations in order, then run:

```bash
psql "$DATABASE_URL" -f migrations/005_teacher_portal.sql
```

Teacher portal: `http://localhost:8000/teacher-portal.html`
School administrator portal: `http://localhost:8000/school-portal.html` (Teacher mark submissions appear under the Teachers workspace).

### v0.8 API additions
- `GET /api/teacher/profile`
- `GET /api/teacher/assignments`
- `GET /api/teacher/assessments`
- `GET /api/teacher/assessments/:id/marks`
- `POST /api/teacher/assessments/:id/marks`
- `POST /api/teacher/assessments/:id/submit`
- `GET /api/school/mark-submissions` (School Administrator)
- `PATCH /api/school/mark-submissions/:id/review` (School Administrator)

Teacher mark-entry access is enforced by role, school, teacher identity, and matching class/subject/year assignment on the server. A teacher cannot select another teacher's assignment or access an unrelated assessment by changing a browser URL.

### v0.8 verification and limitations
JavaScript syntax checks are run on the server and both portals. This package has not been connected to a live PostgreSQL database, migrations have not been executed against production data, and no deployment or end-to-end browser test has been performed. The mark workflow is an application-level review process, not a Ministry/KNEC-certified grading or approval process. Before production, complete database integration tests, security review, backups, audit coverage, privacy review and deployment hardening.
