import 'dotenv/config';
import bcrypt from 'bcryptjs';
import pg from 'pg';
import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';
const { Pool } = pg;
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required');
const rl = readline.createInterface({ input, output });
try {
  const fullName = (await rl.question('Platform owner full name: ')).trim();
  const email = (await rl.question('Platform owner email: ')).trim().toLowerCase();
  const password = await rl.question('Strong password (12+ characters): ');
  if (!fullName || !email.includes('@') || password.length < 12) throw new Error('Enter a name, valid email and password of at least 12 characters');
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const hash = await bcrypt.hash(password, 12);
  await pool.query(`INSERT INTO platform_users(full_name,email,password_hash,role) VALUES($1,$2,$3,'PLATFORM_OWNER')`, [fullName,email,hash]);
  await pool.end();
  console.log('Platform Owner account created. Keep the password private.');
} finally { rl.close(); }
