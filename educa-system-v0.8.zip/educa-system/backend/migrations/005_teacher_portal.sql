-- EDUCA SYSTEM v0.8 teacher mark submission and school review workflow
CREATE TABLE IF NOT EXISTS teacher_assessment_submissions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
 assessment_id UUID NOT NULL, teacher_id UUID NOT NULL, status TEXT NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','SUBMITTED','APPROVED','RETURNED')),
 submitted_at TIMESTAMPTZ, reviewed_by UUID REFERENCES platform_users(id), reviewed_at TIMESTAMPTZ, review_note TEXT NOT NULL DEFAULT '', updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(school_id,assessment_id,teacher_id),
 FOREIGN KEY(assessment_id,school_id) REFERENCES academic_assessments(id,school_id) ON DELETE CASCADE,
 FOREIGN KEY(teacher_id,school_id) REFERENCES platform_users(id,school_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_teacher_submissions_review ON teacher_assessment_submissions(school_id,status,submitted_at DESC);
