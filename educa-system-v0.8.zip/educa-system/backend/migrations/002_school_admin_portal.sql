ALTER TABLE platform_users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS school_classes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  level TEXT NOT NULL,
  stream TEXT NOT NULL DEFAULT '',
  academic_year TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (id, school_id),
  UNIQUE (school_id, name, stream, academic_year)
);
CREATE INDEX IF NOT EXISTS idx_school_classes_school ON school_classes(school_id, academic_year);

CREATE TABLE IF NOT EXISTS school_students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id UUID NOT NULL,
  admission_no TEXT NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  gender TEXT NOT NULL CHECK (gender IN ('Female','Male','Prefer not to say')),
  guardian_name TEXT NOT NULL DEFAULT '',
  guardian_phone TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','INACTIVE')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (school_id, admission_no),
  UNIQUE (id, school_id),
  FOREIGN KEY (class_id, school_id) REFERENCES school_classes(id, school_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_school_students_school ON school_students(school_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_school_students_class ON school_students(school_id, class_id);

CREATE TABLE IF NOT EXISTS attendance_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  student_id UUID NOT NULL,
  attendance_date DATE NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('PRESENT','ABSENT','LATE','EXCUSED')),
  recorded_by UUID NOT NULL REFERENCES platform_users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (student_id, attendance_date),
  FOREIGN KEY (student_id, school_id) REFERENCES school_students(id, school_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_attendance_school_date ON attendance_records(school_id, attendance_date);
