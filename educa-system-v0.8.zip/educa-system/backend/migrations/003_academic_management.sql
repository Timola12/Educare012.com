-- EDUCA SYSTEM v0.6 academic management
CREATE TABLE IF NOT EXISTS school_subjects (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
 code TEXT NOT NULL, name TEXT NOT NULL, curriculum TEXT NOT NULL CHECK (curriculum IN ('CBC','844','GENERAL')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(id,school_id), UNIQUE(school_id,code)
);
CREATE TABLE IF NOT EXISTS class_subjects (
 school_id UUID NOT NULL, class_id UUID NOT NULL, subject_id UUID NOT NULL, PRIMARY KEY(school_id,class_id,subject_id),
 FOREIGN KEY(class_id,school_id) REFERENCES school_classes(id,school_id) ON DELETE CASCADE,
 FOREIGN KEY(subject_id,school_id) REFERENCES school_subjects(id,school_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS academic_assessments (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
 class_id UUID NOT NULL, subject_id UUID NOT NULL, title TEXT NOT NULL,
 curriculum TEXT NOT NULL CHECK(curriculum IN ('CBC','844','GENERAL')),
 assessment_type TEXT NOT NULL CHECK(assessment_type IN ('FORMATIVE','SUMMATIVE','EXAM')),
 academic_year TEXT NOT NULL, term TEXT NOT NULL CHECK(term IN ('TERM_1','TERM_2','TERM_3')),
 assessment_date DATE NOT NULL, max_score NUMERIC(7,2) NOT NULL CHECK(max_score>0 AND max_score<=10000),
 created_by UUID NOT NULL REFERENCES platform_users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(id,school_id),
 FOREIGN KEY(class_id,school_id) REFERENCES school_classes(id,school_id) ON DELETE CASCADE,
 FOREIGN KEY(subject_id,school_id) REFERENCES school_subjects(id,school_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_academic_assessments_school_class ON academic_assessments(school_id,class_id,academic_year,term);
CREATE TABLE IF NOT EXISTS assessment_marks (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), school_id UUID NOT NULL, assessment_id UUID NOT NULL, student_id UUID NOT NULL,
 score NUMERIC(7,2) NOT NULL CHECK(score>=0), teacher_comment TEXT NOT NULL DEFAULT '', entered_by UUID NOT NULL REFERENCES platform_users(id),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(assessment_id,student_id),
 FOREIGN KEY(assessment_id,school_id) REFERENCES academic_assessments(id,school_id) ON DELETE CASCADE,
 FOREIGN KEY(student_id,school_id) REFERENCES school_students(id,school_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_assessment_marks_student ON assessment_marks(school_id,student_id);
