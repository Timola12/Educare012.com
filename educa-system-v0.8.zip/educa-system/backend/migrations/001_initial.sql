CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS platform_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('PLATFORM_OWNER','SCHOOL_ADMIN','TEACHER','BURSAR','PARENT','STUDENT')),
  school_id UUID,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS schools (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  school_type TEXT NOT NULL,
  county TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','SUSPENDED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE platform_users ADD CONSTRAINT platform_users_school_fk FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE SET NULL;
CREATE TABLE IF NOT EXISTS subscription_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  duration_days INTEGER NOT NULL CHECK (duration_days > 0),
  price_kes NUMERIC(12,2) NOT NULL CHECK (price_kes >= 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS school_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  plan_id UUID NOT NULL REFERENCES subscription_plans(id),
  starts_at DATE NOT NULL,
  expires_at DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','EXPIRED','CANCELLED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS subscription_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES schools(id),
  subscription_id UUID REFERENCES school_subscriptions(id),
  amount_kes NUMERIC(12,2) NOT NULL CHECK (amount_kes > 0),
  payment_method TEXT NOT NULL,
  transaction_reference TEXT NOT NULL UNIQUE,
  paid_at TIMESTAMPTZ NOT NULL,
  recorded_by UUID NOT NULL REFERENCES platform_users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGSERIAL PRIMARY KEY,
  actor_user_id UUID REFERENCES platform_users(id),
  action TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_users_school ON platform_users(school_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_school ON school_subscriptions(school_id, status);
CREATE INDEX IF NOT EXISTS idx_subscription_payments_school ON subscription_payments(school_id, paid_at DESC);
INSERT INTO subscription_plans(code,name,duration_days,price_kes) VALUES
 ('monthly','Monthly',30,2500),('termly','Termly',90,6500),('annual','Annual',365,20000)
ON CONFLICT (code) DO NOTHING;
