-- EDUCA SYSTEM v0.7 teacher management
CREATE UNIQUE INDEX IF NOT EXISTS idx_platform_users_id_school_unique ON platform_users(id,school_id);
CREATE TABLE IF NOT EXISTS teacher_subject_assignments (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
 teacher_id UUID NOT NULL REFERENCES platform_users(id) ON DELETE CASCADE, class_id UUID NOT NULL, subject_id UUID NOT NULL,
 academic_year TEXT NOT NULL CHECK (academic_year ~ '^20[0-9]{2}$'), assigned_by UUID NOT NULL REFERENCES platform_users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE (school_id,teacher_id,class_id,subject_id,academic_year),
 FOREIGN KEY (teacher_id,school_id) REFERENCES platform_users(id,school_id) ON DELETE CASCADE,
 FOREIGN KEY (class_id,school_id) REFERENCES school_classes(id,school_id) ON DELETE CASCADE,
 FOREIGN KEY (subject_id,school_id) REFERENCES school_subjects(id,school_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_teacher_assignments_school ON teacher_subject_assignments(school_id,teacher_id,academic_year);
CREATE TABLE IF NOT EXISTS teacher_attendance (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
 teacher_id UUID NOT NULL REFERENCES platform_users(id) ON DELETE CASCADE, attendance_date DATE NOT NULL,
 status TEXT NOT NULL CHECK (status IN ('PRESENT','ABSENT','LATE','LEAVE')), note TEXT NOT NULL DEFAULT '',
 recorded_by UUID NOT NULL REFERENCES platform_users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE (school_id,teacher_id,attendance_date),
 FOREIGN KEY (teacher_id,school_id) REFERENCES platform_users(id,school_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_teacher_attendance_school_date ON teacher_attendance(school_id,attendance_date);
