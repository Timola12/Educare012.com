import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import pg from 'pg';
import { z } from 'zod';

const { Pool } = pg;
const required = ['DATABASE_URL', 'JWT_SECRET'];
for (const key of required) if (!process.env[key]) throw new Error(`${key} is required`);
if (process.env.JWT_SECRET.length < 32) throw new Error('JWT_SECRET must be at least 32 characters');
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: true } : false });
const app = express();
app.use(helmet());
app.use(cors({ origin: (process.env.CORS_ORIGIN || '').split(',').filter(Boolean), credentials: true }));
app.use(express.json({ limit: '200kb' }));
app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false }));

function auth(requiredRole) {
  return async (req, res, next) => {
    try {
      const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
      if (!token) return res.status(401).json({ error: 'Authentication required' });
      const payload = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });
      const { rows } = await pool.query('SELECT id, full_name, email, role, school_id, is_active FROM platform_users WHERE id=$1', [payload.sub]);
      const user = rows[0];
      if (!user || !user.is_active) return res.status(401).json({ error: 'Account unavailable' });
      if (requiredRole && user.role !== requiredRole) return res.status(403).json({ error: 'Insufficient permissions' });
      if (user.role === 'SCHOOL_ADMIN' || user.role === 'TEACHER' || user.role === 'BURSAR') {
        if (!user.school_id) return res.status(403).json({ error: 'This account is not assigned to a school' });
        const access = await pool.query(`SELECT s.status, EXISTS (SELECT 1 FROM school_subscriptions ss WHERE ss.school_id=s.id AND ss.status='ACTIVE' AND ss.starts_at<=CURRENT_DATE AND ss.expires_at>=CURRENT_DATE) AS subscription_valid FROM schools s WHERE s.id=$1`, [user.school_id]);
        if (!access.rows[0] || access.rows[0].status !== 'ACTIVE') return res.status(403).json({ error: 'This school account is currently suspended' });
        if (!access.rows[0].subscription_valid) return res.status(403).json({ error: 'The school subscription is not currently active. Contact EDUCA SYSTEM support.' });
      }
      req.user = user;
      next();
    } catch { return res.status(401).json({ error: 'Invalid or expired session' }); }
  };
}
const loginSchema = z.object({ email: z.string().email().max(254), password: z.string().min(1).max(200) });
app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'EDUCA SYSTEM API' }));
app.post('/api/auth/login', async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Valid email and password are required' });
  const { email, password } = parsed.data;
  const { rows } = await pool.query('SELECT id, full_name, email, password_hash, role, school_id, is_active, must_change_password FROM platform_users WHERE lower(email)=lower($1)', [email]);
  const user = rows[0];
  if (!user || !user.is_active || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ role: user.role }, process.env.JWT_SECRET, { subject: user.id, expiresIn: process.env.JWT_EXPIRES_IN || '15m', algorithm: 'HS256' });
  res.json({ accessToken: token, tokenType: 'Bearer', expiresIn: process.env.JWT_EXPIRES_IN || '15m', user: { id: user.id, fullName: user.full_name, email: user.email, role: user.role, schoolId: user.school_id, mustChangePassword: user.must_change_password } });
});
app.get('/api/owner/overview', auth('PLATFORM_OWNER'), async (_req, res) => {
  const [schools, revenue] = await Promise.all([
    pool.query(`SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE status='ACTIVE')::int AS active, COUNT(*) FILTER (WHERE status='SUSPENDED')::int AS suspended FROM schools`),
    pool.query('SELECT COALESCE(SUM(amount_kes),0)::numeric AS total_kes FROM subscription_payments')
  ]);
  res.json({ ...schools.rows[0], recordedRevenueKes: revenue.rows[0].total_kes });
});
const schoolSchema = z.object({ name: z.string().trim().min(2).max(180), schoolType: z.enum(['Primary School','Junior School','Secondary School','Primary & Junior School','Primary & Secondary School','Comprehensive School']), county: z.string().trim().min(2).max(80), adminName: z.string().trim().min(2).max(160).optional(), adminEmail: z.string().email().max(254).optional() });
app.get('/api/owner/schools', auth('PLATFORM_OWNER'), async (_req, res) => {
  const { rows } = await pool.query(`SELECT s.id,s.name,s.school_type AS "schoolType",s.county,s.status,s.created_at AS "createdAt",u.full_name AS "adminName",u.email AS "adminEmail",sub.plan_id AS "planId",sp.name AS "planName",sub.expires_at AS "expiresAt" FROM schools s LEFT JOIN platform_users u ON u.school_id=s.id AND u.role='SCHOOL_ADMIN' LEFT JOIN LATERAL (SELECT plan_id,expires_at FROM school_subscriptions WHERE school_id=s.id ORDER BY created_at DESC LIMIT 1) sub ON TRUE LEFT JOIN subscription_plans sp ON sp.id=sub.plan_id ORDER BY s.created_at DESC`);
  res.json({ schools: rows });
});
app.post('/api/owner/schools', auth('PLATFORM_OWNER'), async (req, res) => {
  const parsed = schoolSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid school details', details: parsed.error.flatten() });
  const { name, schoolType, county } = parsed.data;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query('INSERT INTO schools(name,school_type,county) VALUES($1,$2,$3) RETURNING id,name,school_type AS "schoolType",county,status', [name, schoolType, county]);
    await client.query('INSERT INTO audit_logs(actor_user_id,action,target_type,target_id,details) VALUES($1,$2,$3,$4,$5)', [req.user.id,'SCHOOL_CREATED','school',rows[0].id,JSON.stringify({name})]);
    await client.query('COMMIT');
    res.status(201).json({ school: rows[0] });
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
});

const subscriptionSchema = z.object({ planId: z.string().uuid(), startsAt: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), expiresAt: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) });
app.post('/api/owner/schools/:id/subscription', auth('PLATFORM_OWNER'), async (req, res) => {
  const parsed = subscriptionSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Valid plan and subscription dates are required' });
  if (parsed.data.expiresAt < parsed.data.startsAt) return res.status(400).json({ error: 'Expiry date must be on or after the start date' });
  try {
    const { rows } = await pool.query(`INSERT INTO school_subscriptions(school_id,plan_id,starts_at,expires_at) SELECT $1,$2,$3,$4 WHERE EXISTS (SELECT 1 FROM schools WHERE id=$1) AND EXISTS (SELECT 1 FROM subscription_plans WHERE id=$2 AND is_active=TRUE) RETURNING id,school_id AS "schoolId",plan_id AS "planId",starts_at AS "startsAt",expires_at AS "expiresAt",status`, [req.params.id, parsed.data.planId, parsed.data.startsAt, parsed.data.expiresAt]);
    if (!rows[0]) return res.status(404).json({ error: 'School or active subscription plan not found' });
    await pool.query('INSERT INTO audit_logs(actor_user_id,action,target_type,target_id,details) VALUES($1,$2,$3,$4,$5)', [req.user.id,'SCHOOL_SUBSCRIPTION_ASSIGNED','school',req.params.id,JSON.stringify({planId:parsed.data.planId,expiresAt:parsed.data.expiresAt})]);
    res.status(201).json({ subscription: rows[0] });
  } catch (e) { if (e.code === '23503') return res.status(404).json({ error: 'School or plan not found' }); throw e; }
});
app.get('/api/owner/subscription-payments', auth('PLATFORM_OWNER'), async (_req, res) => {
  const { rows } = await pool.query(`SELECT p.id,p.school_id AS "schoolId",s.name AS "schoolName",p.amount_kes AS "amountKes",p.payment_method AS "paymentMethod",p.transaction_reference AS "transactionReference",p.paid_at AS "paidAt" FROM subscription_payments p JOIN schools s ON s.id=p.school_id ORDER BY p.paid_at DESC`);
  res.json({ payments: rows });
});

app.patch('/api/owner/schools/:id/status', auth('PLATFORM_OWNER'), async (req, res) => {
  const schema = z.object({ status: z.enum(['ACTIVE','SUSPENDED']) }); const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Status must be ACTIVE or SUSPENDED' });
  const { rows } = await pool.query('UPDATE schools SET status=$1 WHERE id=$2 RETURNING id,name,status', [parsed.data.status, req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: 'School not found' });
  await pool.query('INSERT INTO audit_logs(actor_user_id,action,target_type,target_id,details) VALUES($1,$2,$3,$4,$5)', [req.user.id,'SCHOOL_STATUS_CHANGED','school',rows[0].id,JSON.stringify({status:rows[0].status})]);
  res.json({ school: rows[0] });
});
const paymentSchema = z.object({ schoolId: z.string().uuid(), amountKes: z.number().positive().max(100000000), paymentMethod: z.enum(['M-Pesa','Bank','Cash','Other']), transactionReference: z.string().trim().min(3).max(120), paidAt: z.string().datetime() });
app.get('/api/owner/plans', auth('PLATFORM_OWNER'), async (_req, res) => {
  const { rows } = await pool.query('SELECT id,code,name,duration_days AS "durationDays",price_kes AS "priceKes",is_active AS "isActive" FROM subscription_plans ORDER BY duration_days');
  res.json({ plans: rows });
});
app.patch('/api/owner/plans/:id', auth('PLATFORM_OWNER'), async (req, res) => {
  const parsed = z.object({ priceKes: z.number().min(0).max(100000000), isActive: z.boolean().optional() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid plan update' });
  const { rows } = await pool.query('UPDATE subscription_plans SET price_kes=$1,is_active=COALESCE($2,is_active) WHERE id=$3 RETURNING id,code,name,duration_days AS "durationDays",price_kes AS "priceKes",is_active AS "isActive"', [parsed.data.priceKes, parsed.data.isActive ?? null, req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: 'Plan not found' });
  await pool.query('INSERT INTO audit_logs(actor_user_id,action,target_type,target_id,details) VALUES($1,$2,$3,$4,$5)', [req.user.id,'SUBSCRIPTION_PLAN_UPDATED','subscription_plan',rows[0].id,JSON.stringify({priceKes:rows[0].priceKes})]);
  res.json({ plan: rows[0] });
});
app.post('/api/owner/subscription-payments', auth('PLATFORM_OWNER'), async (req, res) => {
  const parsed = paymentSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid payment details', details: parsed.error.flatten() });
  const p = parsed.data;
  try {
    const { rows } = await pool.query(`INSERT INTO subscription_payments(school_id,amount_kes,payment_method,transaction_reference,paid_at,recorded_by) VALUES($1,$2,$3,$4,$5,$6) RETURNING id,school_id AS "schoolId",amount_kes AS "amountKes",payment_method AS "paymentMethod",transaction_reference AS "transactionReference",paid_at AS "paidAt"`, [p.schoolId,p.amountKes,p.paymentMethod,p.transactionReference,p.paidAt,req.user.id]);
    await pool.query('INSERT INTO audit_logs(actor_user_id,action,target_type,target_id,details) VALUES($1,$2,$3,$4,$5)', [req.user.id,'SUBSCRIPTION_PAYMENT_RECORDED','subscription_payment',rows[0].id,JSON.stringify({schoolId:p.schoolId,amountKes:p.amountKes})]);
    res.status(201).json({ payment: rows[0] });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'That transaction reference has already been recorded' });
    if (e.code === '23503') return res.status(404).json({ error: 'School not found' });
    throw e;
  }
});

// Password change is required for school accounts provisioned by the Platform Owner.
app.post('/api/auth/change-password', auth(), async (req, res) => {
  const parsed = z.object({ currentPassword: z.string().min(1).max(200), newPassword: z.string().min(12).max(200) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'New password must contain at least 12 characters' });
  const { rows } = await pool.query('SELECT password_hash FROM platform_users WHERE id=$1', [req.user.id]);
  if (!rows[0] || !(await bcrypt.compare(parsed.data.currentPassword, rows[0].password_hash))) return res.status(400).json({ error: 'Current password is incorrect' });
  const hash = await bcrypt.hash(parsed.data.newPassword, 12);
  await pool.query('UPDATE platform_users SET password_hash=$1,must_change_password=FALSE WHERE id=$2', [hash, req.user.id]);
  res.json({ message: 'Password updated successfully' });
});

const adminSchema = z.object({ fullName: z.string().trim().min(2).max(160), email: z.string().email().max(254), initialPassword: z.string().min(12).max(200) });
app.get('/api/owner/school-admins', auth('PLATFORM_OWNER'), async (_req, res) => {
  const { rows } = await pool.query(`SELECT u.id,u.full_name AS "fullName",u.email,u.is_active AS "isActive",u.must_change_password AS "mustChangePassword",u.created_at AS "createdAt",s.id AS "schoolId",s.name AS "schoolName" FROM platform_users u JOIN schools s ON s.id=u.school_id WHERE u.role='SCHOOL_ADMIN' ORDER BY u.created_at DESC`);
  res.json({ admins: rows });
});
app.post('/api/owner/schools/:id/admin', auth('PLATFORM_OWNER'), async (req, res) => {
  const parsed = adminSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Enter a valid name, email and initial password of at least 12 characters' });
  const school = await pool.query('SELECT id FROM schools WHERE id=$1', [req.params.id]);
  if (!school.rows[0]) return res.status(404).json({ error: 'School not found' });
  const hash = await bcrypt.hash(parsed.data.initialPassword, 12);
  try {
    const { rows } = await pool.query(`INSERT INTO platform_users(full_name,email,password_hash,role,school_id,must_change_password) VALUES($1,$2,$3,'SCHOOL_ADMIN',$4,TRUE) RETURNING id,full_name AS "fullName",email,school_id AS "schoolId",must_change_password AS "mustChangePassword"`, [parsed.data.fullName,parsed.data.email.toLowerCase(),hash,req.params.id]);
    await pool.query('INSERT INTO audit_logs(actor_user_id,action,target_type,target_id,details) VALUES($1,$2,$3,$4,$5)', [req.user.id,'SCHOOL_ADMIN_CREATED','platform_user',rows[0].id,JSON.stringify({schoolId:req.params.id,email:rows[0].email})]);
    res.status(201).json({ admin: rows[0] });
  } catch (e) { if (e.code === '23505') return res.status(409).json({ error: 'An account with this email already exists' }); throw e; }
});

// School administrator workspace. Every read/write is scoped to the authenticated user's school_id.
const schoolAdmin = auth('SCHOOL_ADMIN');
app.get('/api/school/profile', schoolAdmin, async (req, res) => {
  const { rows } = await pool.query(`SELECT id,name,school_type AS "schoolType",county FROM schools WHERE id=$1`, [req.user.school_id]);
  res.json({ school: rows[0], user: { fullName: req.user.full_name, email: req.user.email } });
});
app.get('/api/school/classes', schoolAdmin, async (req, res) => {
  const { rows } = await pool.query(`SELECT c.id,c.name,c.level,c.stream,c.academic_year AS "academicYear",COUNT(st.id)::int AS "studentCount" FROM school_classes c LEFT JOIN school_students st ON st.class_id=c.id AND st.school_id=c.school_id WHERE c.school_id=$1 GROUP BY c.id ORDER BY c.level,c.name`, [req.user.school_id]);
  res.json({ classes: rows });
});
const classSchema = z.object({ name: z.string().trim().min(1).max(80), level: z.string().trim().min(1).max(60), stream: z.string().trim().max(40).optional().default(''), academicYear: z.string().regex(/^20\d{2}$/) });
app.post('/api/school/classes', schoolAdmin, async (req, res) => {
  const parsed = classSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Enter a class name, level and valid academic year' });
  try {
    const { rows } = await pool.query(`INSERT INTO school_classes(school_id,name,level,stream,academic_year) VALUES($1,$2,$3,$4,$5) RETURNING id,name,level,stream,academic_year AS "academicYear"`, [req.user.school_id,parsed.data.name,parsed.data.level,parsed.data.stream,parsed.data.academicYear]);
    res.status(201).json({ class: rows[0] });
  } catch (e) { if (e.code === '23505') return res.status(409).json({ error: 'That class and stream already exists for this academic year' }); throw e; }
});
app.get('/api/school/students', schoolAdmin, async (req, res) => {
  const { rows } = await pool.query(`SELECT st.id,st.admission_no AS "admissionNo",st.first_name AS "firstName",st.last_name AS "lastName",st.gender,st.guardian_name AS "guardianName",st.guardian_phone AS "guardianPhone",st.status,c.name AS "className",c.level FROM school_students st LEFT JOIN school_classes c ON c.id=st.class_id AND c.school_id=st.school_id WHERE st.school_id=$1 ORDER BY st.created_at DESC`, [req.user.school_id]);
  res.json({ students: rows });
});
const studentSchema = z.object({ admissionNo: z.string().trim().min(1).max(40), firstName: z.string().trim().min(1).max(80), lastName: z.string().trim().min(1).max(80), gender: z.enum(['Female','Male','Prefer not to say']), classId: z.string().uuid(), guardianName: z.string().trim().max(160).optional().default(''), guardianPhone: z.string().trim().max(30).optional().default('') });
app.post('/api/school/students', schoolAdmin, async (req, res) => {
  const parsed = studentSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Complete the student details and select a class' });
  const p = parsed.data;
  try {
    const { rows } = await pool.query(`INSERT INTO school_students(school_id,class_id,admission_no,first_name,last_name,gender,guardian_name,guardian_phone) SELECT $1,c.id,$3,$4,$5,$6,$7,$8 FROM school_classes c WHERE c.id=$2 AND c.school_id=$1 RETURNING id,admission_no AS "admissionNo",first_name AS "firstName",last_name AS "lastName",gender,guardian_name AS "guardianName",guardian_phone AS "guardianPhone",status`, [req.user.school_id,p.classId,p.admissionNo,p.firstName,p.lastName,p.gender,p.guardianName,p.guardianPhone]);
    if (!rows[0]) return res.status(400).json({ error: 'Selected class does not belong to your school' });
    res.status(201).json({ student: rows[0] });
  } catch (e) { if (e.code === '23505') return res.status(409).json({ error: 'Admission number already exists in this school' }); throw e; }
});
app.get('/api/school/attendance', schoolAdmin, async (req, res) => {
  const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).safeParse(req.query.date);
  if (!date.success) return res.status(400).json({ error: 'A valid attendance date is required' });
  const { rows } = await pool.query(`SELECT a.student_id AS "studentId",a.status,st.admission_no AS "admissionNo",st.first_name AS "firstName",st.last_name AS "lastName",c.name AS "className" FROM attendance_records a JOIN school_students st ON st.id=a.student_id AND st.school_id=a.school_id LEFT JOIN school_classes c ON c.id=st.class_id AND c.school_id=st.school_id WHERE a.school_id=$1 AND a.attendance_date=$2 ORDER BY st.first_name,st.last_name`, [req.user.school_id,date.data]);
  res.json({ attendance: rows });
});
app.post('/api/school/attendance', schoolAdmin, async (req, res) => {
  const parsed = z.object({ studentId: z.string().uuid(), date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), status: z.enum(['PRESENT','ABSENT','LATE','EXCUSED']) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid attendance record' });
  const p = parsed.data;
  const { rows } = await pool.query(`INSERT INTO attendance_records(school_id,student_id,attendance_date,status,recorded_by) SELECT $1,st.id,$3,$4,$5 FROM school_students st WHERE st.id=$2 AND st.school_id=$1 ON CONFLICT(student_id,attendance_date) DO UPDATE SET status=EXCLUDED.status,recorded_by=EXCLUDED.recorded_by RETURNING student_id AS "studentId",attendance_date AS date,status`, [req.user.school_id,p.studentId,p.date,p.status,req.user.id]);
  if (!rows[0]) return res.status(404).json({ error: 'Student not found in your school' });
  res.json({ attendance: rows[0] });
});


// Academic management: all resources and joins are constrained to the signed-in school.
const academicCurriculum = z.enum(['CBC','844','GENERAL']);
app.get('/api/school/subjects', schoolAdmin, async (req,res) => {
 const {rows}=await pool.query(`SELECT id,code,name,curriculum FROM school_subjects WHERE school_id=$1 ORDER BY name`,[req.user.school_id]);
 res.json({subjects:rows});
});
app.post('/api/school/subjects', schoolAdmin, async (req,res) => {
 const parsed=z.object({code:z.string().trim().min(1).max(20),name:z.string().trim().min(2).max(100),curriculum:academicCurriculum}).safeParse(req.body);
 if(!parsed.success)return res.status(400).json({error:'Enter a subject code, name and curriculum (CBC, 8-4-4 or general).'});
 try {const p=parsed.data;const {rows}=await pool.query(`INSERT INTO school_subjects(school_id,code,name,curriculum) VALUES($1,$2,$3,$4) RETURNING id,code,name,curriculum`,[req.user.school_id,p.code.toUpperCase(),p.name,p.curriculum]);res.status(201).json({subject:rows[0]});}
 catch(e){if(e.code==='23505')return res.status(409).json({error:'That subject code already exists in your school.'});throw e;}
});
app.get('/api/school/assessments', schoolAdmin, async (req,res) => {
 const {rows}=await pool.query(`SELECT a.id,a.title,a.curriculum,a.assessment_type AS "assessmentType",a.academic_year AS "academicYear",a.term,a.assessment_date AS "assessmentDate",a.max_score AS "maxScore",a.class_id AS "classId",c.name AS "className",a.subject_id AS "subjectId",s.name AS "subjectName",COUNT(m.id)::int AS "marksEntered" FROM academic_assessments a JOIN school_classes c ON c.id=a.class_id AND c.school_id=a.school_id JOIN school_subjects s ON s.id=a.subject_id AND s.school_id=a.school_id LEFT JOIN assessment_marks m ON m.assessment_id=a.id AND m.school_id=a.school_id WHERE a.school_id=$1 GROUP BY a.id,c.name,s.name ORDER BY a.assessment_date DESC,a.created_at DESC`,[req.user.school_id]);
 res.json({assessments:rows});
});
const assessmentSchema=z.object({classId:z.string().uuid(),subjectId:z.string().uuid(),title:z.string().trim().min(2).max(120),curriculum:academicCurriculum,assessmentType:z.enum(['FORMATIVE','SUMMATIVE','EXAM']),academicYear:z.string().regex(/^20\d{2}$/),term:z.enum(['TERM_1','TERM_2','TERM_3']),assessmentDate:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),maxScore:z.number().positive().max(10000)});
app.post('/api/school/assessments', schoolAdmin, async (req,res) => {
 const parsed=assessmentSchema.safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'Check the assessment details and try again.'});const p=parsed.data;
 const {rows}=await pool.query(`INSERT INTO academic_assessments(school_id,class_id,subject_id,title,curriculum,assessment_type,academic_year,term,assessment_date,max_score,created_by) SELECT $1,c.id,s.id,$4,$5,$6,$7,$8,$9,$10,$11 FROM school_classes c JOIN school_subjects s ON s.id=$3 AND s.school_id=$1 WHERE c.id=$2 AND c.school_id=$1 AND c.academic_year=$7 RETURNING id,title,curriculum,assessment_type AS "assessmentType",academic_year AS "academicYear",term,assessment_date AS "assessmentDate",max_score AS "maxScore",class_id AS "classId",subject_id AS "subjectId"`,[req.user.school_id,p.classId,p.subjectId,p.title,p.curriculum,p.assessmentType,p.academicYear,p.term,p.assessmentDate,p.maxScore,req.user.id]);
 if(!rows[0])return res.status(400).json({error:'Selected class and subject must both belong to your school, and the class academic year must match.'});res.status(201).json({assessment:rows[0]});
});
app.get('/api/school/assessments/:id/marks', schoolAdmin, async (req,res) => {
 const {rows}=await pool.query(`SELECT st.id AS "studentId",st.admission_no AS "admissionNo",st.first_name AS "firstName",st.last_name AS "lastName",m.score,m.teacher_comment AS "teacherComment" FROM academic_assessments a JOIN school_students st ON st.school_id=a.school_id AND st.class_id=a.class_id AND st.status='ACTIVE' LEFT JOIN assessment_marks m ON m.assessment_id=a.id AND m.student_id=st.id AND m.school_id=a.school_id WHERE a.id=$1 AND a.school_id=$2 ORDER BY st.first_name,st.last_name`,[req.params.id,req.user.school_id]);
 const meta=await pool.query(`SELECT id,title,max_score AS "maxScore",class_id AS "classId" FROM academic_assessments WHERE id=$1 AND school_id=$2`,[req.params.id,req.user.school_id]);if(!meta.rows[0])return res.status(404).json({error:'Assessment not found.'});res.json({assessment:meta.rows[0],marks:rows});
});
app.post('/api/school/assessments/:id/marks', schoolAdmin, async (req,res) => {
 const parsed=z.object({marks:z.array(z.object({studentId:z.string().uuid(),score:z.number().min(0),teacherComment:z.string().max(500).optional().default('')})).min(1).max(500)}).safeParse(req.body);
 if(!parsed.success)return res.status(400).json({error:'Provide valid student scores.'});
 const client=await pool.connect();try{await client.query('BEGIN');const a=await client.query('SELECT max_score FROM academic_assessments WHERE id=$1 AND school_id=$2 FOR UPDATE',[req.params.id,req.user.school_id]);if(!a.rows[0]){await client.query('ROLLBACK');return res.status(404).json({error:'Assessment not found.'});}
 for(const m of parsed.data.marks){if(m.score>Number(a.rows[0].max_score)){await client.query('ROLLBACK');return res.status(400).json({error:`A score cannot exceed the maximum of ${a.rows[0].max_score}.`});}
 const saved=await client.query(`INSERT INTO assessment_marks(school_id,assessment_id,student_id,score,teacher_comment,entered_by) SELECT $1,$2,st.id,$4,$5,$6 FROM school_students st JOIN academic_assessments a ON a.id=$2 AND a.school_id=$1 AND a.class_id=st.class_id WHERE st.id=$3 AND st.school_id=$1 AND st.status='ACTIVE' ON CONFLICT(assessment_id,student_id) DO UPDATE SET score=EXCLUDED.score,teacher_comment=EXCLUDED.teacher_comment,entered_by=EXCLUDED.entered_by,updated_at=now() RETURNING id`,[req.user.school_id,req.params.id,m.studentId,m.score,m.teacherComment,req.user.id]);if(!saved.rows[0]){await client.query('ROLLBACK');return res.status(400).json({error:'A selected student is not an active learner in this assessment class.'});}}
 await client.query('COMMIT');res.json({saved:parsed.data.marks.length});}catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
});
app.get('/api/school/students/:id/report', schoolAdmin, async (req,res) => {
 const student=await pool.query(`SELECT st.id,st.admission_no AS "admissionNo",st.first_name AS "firstName",st.last_name AS "lastName",c.name AS "className",c.level,c.academic_year AS "academicYear" FROM school_students st JOIN school_classes c ON c.id=st.class_id AND c.school_id=st.school_id WHERE st.id=$1 AND st.school_id=$2`,[req.params.id,req.user.school_id]);if(!student.rows[0])return res.status(404).json({error:'Student not found.'});
 const {rows}=await pool.query(`SELECT a.title,a.curriculum,a.assessment_type AS "assessmentType",a.academic_year AS "academicYear",a.term,s.name AS "subjectName",a.max_score AS "maxScore",m.score,m.teacher_comment AS "teacherComment",a.assessment_date AS "assessmentDate" FROM academic_assessments a JOIN school_subjects s ON s.id=a.subject_id AND s.school_id=a.school_id LEFT JOIN assessment_marks m ON m.assessment_id=a.id AND m.student_id=$1 AND m.school_id=a.school_id WHERE a.school_id=$2 AND a.class_id=(SELECT class_id FROM school_students WHERE id=$1 AND school_id=$2) ORDER BY a.academic_year DESC,a.term,s.name,a.assessment_date`,[req.params.id,req.user.school_id]);
 res.json({student:student.rows[0],results:rows});
});


// Teacher management — only school administrators can provision and manage teacher records.
const teacherSchema = z.object({fullName:z.string().trim().min(2).max(160),email:z.string().email().max(254),initialPassword:z.string().min(12).max(200)});
app.get('/api/school/teachers', schoolAdmin, async (req,res) => {
 const {rows}=await pool.query(`SELECT u.id,u.full_name AS "fullName",u.email,u.is_active AS "isActive",u.must_change_password AS "mustChangePassword",u.created_at AS "createdAt",COUNT(DISTINCT tsa.id)::int AS "assignmentCount" FROM platform_users u LEFT JOIN teacher_subject_assignments tsa ON tsa.teacher_id=u.id AND tsa.school_id=u.school_id WHERE u.school_id=$1 AND u.role='TEACHER' GROUP BY u.id ORDER BY u.full_name`,[req.user.school_id]);res.json({teachers:rows});
});
app.post('/api/school/teachers', schoolAdmin, async (req,res) => {
 const parsed=teacherSchema.safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'Enter a valid teacher name, email and temporary password (at least 12 characters).'});const hash=await bcrypt.hash(parsed.data.initialPassword,12);
 try {const {rows}=await pool.query(`INSERT INTO platform_users(full_name,email,password_hash,role,school_id,must_change_password) VALUES($1,$2,$3,'TEACHER',$4,TRUE) RETURNING id,full_name AS "fullName",email,is_active AS "isActive",must_change_password AS "mustChangePassword"`,[parsed.data.fullName,parsed.data.email.toLowerCase(),hash,req.user.school_id]);await pool.query('INSERT INTO audit_logs(actor_user_id,action,target_type,target_id,details) VALUES($1,$2,$3,$4,$5)',[req.user.id,'TEACHER_CREATED','platform_user',rows[0].id,JSON.stringify({schoolId:req.user.school_id,email:rows[0].email})]);res.status(201).json({teacher:rows[0]});}catch(e){if(e.code==='23505')return res.status(409).json({error:'An account with this email already exists.'});throw e;}
});
app.patch('/api/school/teachers/:id/status', schoolAdmin, async (req,res) => {const parsed=z.object({isActive:z.boolean()}).safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'Choose an active or inactive account status.'});const {rows}=await pool.query(`UPDATE platform_users SET is_active=$1 WHERE id=$2 AND school_id=$3 AND role='TEACHER' RETURNING id,is_active AS "isActive"`,[parsed.data.isActive,req.params.id,req.user.school_id]);if(!rows[0])return res.status(404).json({error:'Teacher not found in your school.'});res.json({teacher:rows[0]});});
app.get('/api/school/teacher-assignments', schoolAdmin, async (req,res) => {const {rows}=await pool.query(`SELECT tsa.id,tsa.teacher_id AS "teacherId",u.full_name AS "teacherName",tsa.class_id AS "classId",c.name AS "className",tsa.subject_id AS "subjectId",s.name AS "subjectName",tsa.academic_year AS "academicYear" FROM teacher_subject_assignments tsa JOIN platform_users u ON u.id=tsa.teacher_id AND u.school_id=tsa.school_id JOIN school_classes c ON c.id=tsa.class_id AND c.school_id=tsa.school_id JOIN school_subjects s ON s.id=tsa.subject_id AND s.school_id=tsa.school_id WHERE tsa.school_id=$1 ORDER BY u.full_name,c.name,s.name`,[req.user.school_id]);res.json({assignments:rows});});
app.post('/api/school/teacher-assignments', schoolAdmin, async (req,res) => {const parsed=z.object({teacherId:z.string().uuid(),classId:z.string().uuid(),subjectId:z.string().uuid(),academicYear:z.string().regex(/^20\d{2}$/)}).safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'Select a teacher, class, subject and valid academic year.'});const p=parsed.data;try{const {rows}=await pool.query(`INSERT INTO teacher_subject_assignments(school_id,teacher_id,class_id,subject_id,academic_year,assigned_by) SELECT $1,u.id,c.id,s.id,$5,$6 FROM platform_users u JOIN school_classes c ON c.id=$3 AND c.school_id=$1 JOIN school_subjects s ON s.id=$4 AND s.school_id=$1 WHERE u.id=$2 AND u.school_id=$1 AND u.role='TEACHER' AND u.is_active=TRUE AND c.academic_year=$5 RETURNING id`,[req.user.school_id,p.teacherId,p.classId,p.subjectId,p.academicYear,req.user.id]);if(!rows[0])return res.status(400).json({error:'Teacher, class and subject must belong to this school; class year must match.'});res.status(201).json({assignment:rows[0]});}catch(e){if(e.code==='23505')return res.status(409).json({error:'This teacher is already assigned to that class and subject for this year.'});throw e;}});
app.delete('/api/school/teacher-assignments/:id', schoolAdmin, async (req,res) => {const {rowCount}=await pool.query('DELETE FROM teacher_subject_assignments WHERE id=$1 AND school_id=$2',[req.params.id,req.user.school_id]);if(!rowCount)return res.status(404).json({error:'Assignment not found.'});res.json({deleted:true});});
app.get('/api/school/teacher-attendance', schoolAdmin, async (req,res) => {const date=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).safeParse(req.query.date);if(!date.success)return res.status(400).json({error:'A valid date is required.'});const {rows}=await pool.query(`SELECT u.id AS "teacherId",u.full_name AS "fullName",u.email,t.status,t.note FROM platform_users u LEFT JOIN teacher_attendance t ON t.teacher_id=u.id AND t.school_id=u.school_id AND t.attendance_date=$2 WHERE u.school_id=$1 AND u.role='TEACHER' AND u.is_active=TRUE ORDER BY u.full_name`,[req.user.school_id,date.data]);res.json({attendance:rows});});
app.post('/api/school/teacher-attendance', schoolAdmin, async (req,res) => {const parsed=z.object({teacherId:z.string().uuid(),date:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),status:z.enum(['PRESENT','ABSENT','LATE','LEAVE']),note:z.string().max(300).optional().default('')}).safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'Invalid teacher attendance record.'});const p=parsed.data;const {rows}=await pool.query(`INSERT INTO teacher_attendance(school_id,teacher_id,attendance_date,status,note,recorded_by) SELECT $1,u.id,$3,$4,$5,$6 FROM platform_users u WHERE u.id=$2 AND u.school_id=$1 AND u.role='TEACHER' ON CONFLICT(school_id,teacher_id,attendance_date) DO UPDATE SET status=EXCLUDED.status,note=EXCLUDED.note,recorded_by=EXCLUDED.recorded_by RETURNING teacher_id AS "teacherId",attendance_date AS date,status,note`,[req.user.school_id,p.teacherId,p.date,p.status,p.note,req.user.id]);if(!rows[0])return res.status(404).json({error:'Teacher not found in your school.'});res.json({attendance:rows[0]});});



// v0.8 Teacher self-service workspace. Every query is constrained by the signed-in teacher and school.
const teacherOnly = auth('TEACHER');
app.get('/api/teacher/profile', teacherOnly, async (req,res) => {
 const {rows}=await pool.query(`SELECT s.name AS "schoolName",u.full_name AS "fullName",u.email FROM platform_users u JOIN schools s ON s.id=u.school_id WHERE u.id=$1 AND u.school_id=$2`,[req.user.id,req.user.school_id]);
 if(!rows[0])return res.status(404).json({error:'Teacher profile not found.'});res.json({profile:rows[0]});
});
app.get('/api/teacher/assignments', teacherOnly, async (req,res) => {
 const {rows}=await pool.query(`SELECT tsa.id,tsa.class_id AS "classId",c.name AS "className",c.level,c.academic_year AS "academicYear",tsa.subject_id AS "subjectId",s.name AS "subjectName" FROM teacher_subject_assignments tsa JOIN school_classes c ON c.id=tsa.class_id AND c.school_id=tsa.school_id JOIN school_subjects s ON s.id=tsa.subject_id AND s.school_id=tsa.school_id WHERE tsa.school_id=$1 AND tsa.teacher_id=$2 ORDER BY c.name,s.name`,[req.user.school_id,req.user.id]);res.json({assignments:rows});
});
app.get('/api/teacher/assessments', teacherOnly, async (req,res) => {
 const {rows}=await pool.query(`SELECT a.id,a.title,a.class_id AS "classId",c.name AS "className",a.subject_id AS "subjectId",s.name AS "subjectName",a.academic_year AS "academicYear",a.term,a.assessment_type AS "assessmentType",a.assessment_date AS "assessmentDate",a.max_score AS "maxScore",COALESCE(ts.status,'NOT_STARTED') AS status,COALESCE((SELECT COUNT(*) FROM assessment_marks m WHERE m.assessment_id=a.id AND m.school_id=a.school_id),0)::int AS "marksEntered",(SELECT COUNT(*) FROM school_students st WHERE st.school_id=a.school_id AND st.class_id=a.class_id AND st.status='ACTIVE')::int AS "learnerCount" FROM academic_assessments a JOIN teacher_subject_assignments tsa ON tsa.school_id=a.school_id AND tsa.class_id=a.class_id AND tsa.subject_id=a.subject_id AND tsa.academic_year=a.academic_year AND tsa.teacher_id=$2 JOIN school_classes c ON c.id=a.class_id AND c.school_id=a.school_id JOIN school_subjects s ON s.id=a.subject_id AND s.school_id=a.school_id LEFT JOIN teacher_assessment_submissions ts ON ts.assessment_id=a.id AND ts.school_id=a.school_id AND ts.teacher_id=$2 WHERE a.school_id=$1 ORDER BY a.assessment_date DESC,a.created_at DESC`,[req.user.school_id,req.user.id]);res.json({assessments:rows});
});
app.get('/api/teacher/assessments/:id/marks', teacherOnly, async (req,res) => {
 const a=await pool.query(`SELECT a.id,a.title,a.max_score AS "maxScore",a.class_id AS "classId",COALESCE(ts.status,'NOT_STARTED') AS status FROM academic_assessments a JOIN teacher_subject_assignments tsa ON tsa.school_id=a.school_id AND tsa.class_id=a.class_id AND tsa.subject_id=a.subject_id AND tsa.academic_year=a.academic_year AND tsa.teacher_id=$3 LEFT JOIN teacher_assessment_submissions ts ON ts.assessment_id=a.id AND ts.school_id=a.school_id AND ts.teacher_id=$3 WHERE a.id=$1 AND a.school_id=$2`,[req.params.id,req.user.school_id,req.user.id]);
 if(!a.rows[0])return res.status(404).json({error:'Assessment is not assigned to your account.'});
 const {rows}=await pool.query(`SELECT st.id AS "studentId",st.admission_no AS "admissionNo",st.first_name AS "firstName",st.last_name AS "lastName",m.score,m.teacher_comment AS "teacherComment" FROM school_students st LEFT JOIN assessment_marks m ON m.assessment_id=$1 AND m.student_id=st.id AND m.school_id=st.school_id WHERE st.school_id=$2 AND st.class_id=$3 AND st.status='ACTIVE' ORDER BY st.first_name,st.last_name`,[req.params.id,req.user.school_id,a.rows[0].classId]);res.json({assessment:a.rows[0],marks:rows});
});
app.post('/api/teacher/assessments/:id/marks', teacherOnly, async (req,res) => {
 const parsed=z.object({marks:z.array(z.object({studentId:z.string().uuid(),score:z.number().min(0),teacherComment:z.string().max(500).optional().default('')})).min(1).max(1000)}).safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'Enter valid marks for at least one learner.'});
 const client=await pool.connect();try{await client.query('BEGIN');const a=await client.query(`SELECT a.max_score,a.class_id FROM academic_assessments a JOIN teacher_subject_assignments tsa ON tsa.school_id=a.school_id AND tsa.class_id=a.class_id AND tsa.subject_id=a.subject_id AND tsa.academic_year=a.academic_year AND tsa.teacher_id=$3 WHERE a.id=$1 AND a.school_id=$2 FOR UPDATE`,[req.params.id,req.user.school_id,req.user.id]);if(!a.rows[0]){await client.query('ROLLBACK');return res.status(404).json({error:'Assessment is not assigned to your account.'});}
 const sub=await client.query(`SELECT status FROM teacher_assessment_submissions WHERE school_id=$1 AND assessment_id=$2 AND teacher_id=$3 FOR UPDATE`,[req.user.school_id,req.params.id,req.user.id]);if(sub.rows[0]&&['SUBMITTED','APPROVED'].includes(sub.rows[0].status)){await client.query('ROLLBACK');return res.status(409).json({error:'This mark sheet has been submitted or approved and is locked. Ask the school administrator to return it for editing.'});}
 for(const m of parsed.data.marks){if(m.score>a.rows[0].max_score){await client.query('ROLLBACK');return res.status(400).json({error:`A score cannot exceed ${a.rows[0].max_score}.`});}const saved=await client.query(`INSERT INTO assessment_marks(school_id,assessment_id,student_id,score,teacher_comment,entered_by) SELECT $1,$2,st.id,$4,$5,$6 FROM school_students st WHERE st.id=$3 AND st.school_id=$1 AND st.class_id=$7 AND st.status='ACTIVE' ON CONFLICT(assessment_id,student_id) DO UPDATE SET score=EXCLUDED.score,teacher_comment=EXCLUDED.teacher_comment,entered_by=EXCLUDED.entered_by,updated_at=now() RETURNING id`,[req.user.school_id,req.params.id,m.studentId,m.score,m.teacherComment,req.user.id,a.rows[0].class_id]);if(!saved.rows[0]){await client.query('ROLLBACK');return res.status(400).json({error:'A learner is not active in this assigned class.'});}}
 await client.query(`INSERT INTO teacher_assessment_submissions(school_id,assessment_id,teacher_id,status,updated_at) VALUES($1,$2,$3,'DRAFT',now()) ON CONFLICT(school_id,assessment_id,teacher_id) DO UPDATE SET status='DRAFT',updated_at=now()`,[req.user.school_id,req.params.id,req.user.id]);await client.query('COMMIT');res.json({saved:true});
 }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
});
app.post('/api/teacher/assessments/:id/submit', teacherOnly, async (req,res) => {
 const client=await pool.connect();try{await client.query('BEGIN');const a=await client.query(`SELECT a.id FROM academic_assessments a JOIN teacher_subject_assignments tsa ON tsa.school_id=a.school_id AND tsa.class_id=a.class_id AND tsa.subject_id=a.subject_id AND tsa.academic_year=a.academic_year AND tsa.teacher_id=$3 WHERE a.id=$1 AND a.school_id=$2 FOR UPDATE`,[req.params.id,req.user.school_id,req.user.id]);if(!a.rows[0]){await client.query('ROLLBACK');return res.status(404).json({error:'Assessment is not assigned to your account.'});}
 const counts=await client.query(`SELECT (SELECT COUNT(*) FROM school_students WHERE school_id=$1 AND class_id=a.class_id AND status='ACTIVE')::int AS total,(SELECT COUNT(*) FROM assessment_marks m JOIN school_students st ON st.id=m.student_id AND st.school_id=m.school_id WHERE m.school_id=$1 AND m.assessment_id=a.id AND st.class_id=a.class_id AND st.status='ACTIVE')::int AS entered FROM academic_assessments a WHERE a.id=$2 AND a.school_id=$1`,[req.user.school_id,req.params.id]);if(counts.rows[0].total!==counts.rows[0].entered){await client.query('ROLLBACK');return res.status(400).json({error:`Complete all learner marks before submitting (${counts.rows[0].entered}/${counts.rows[0].total}).`});}
 await client.query(`INSERT INTO teacher_assessment_submissions(school_id,assessment_id,teacher_id,status,submitted_at,updated_at) VALUES($1,$2,$3,'SUBMITTED',now(),now()) ON CONFLICT(school_id,assessment_id,teacher_id) DO UPDATE SET status='SUBMITTED',submitted_at=now(),reviewed_by=NULL,reviewed_at=NULL,review_note='',updated_at=now()`,[req.user.school_id,req.params.id,req.user.id]);await client.query('COMMIT');res.json({submitted:true});
 }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
});
app.get('/api/school/mark-submissions', schoolAdmin, async (req,res) => {
 const {rows}=await pool.query(`SELECT ts.id,ts.assessment_id AS "assessmentId",a.title,c.name AS "className",s.name AS "subjectName",u.full_name AS "teacherName",ts.status,ts.submitted_at AS "submittedAt",ts.review_note AS "reviewNote",(SELECT COUNT(*) FROM assessment_marks m WHERE m.school_id=ts.school_id AND m.assessment_id=ts.assessment_id)::int AS "marksEntered" FROM teacher_assessment_submissions ts JOIN academic_assessments a ON a.id=ts.assessment_id AND a.school_id=ts.school_id JOIN school_classes c ON c.id=a.class_id AND c.school_id=a.school_id JOIN school_subjects s ON s.id=a.subject_id AND s.school_id=a.school_id JOIN platform_users u ON u.id=ts.teacher_id AND u.school_id=ts.school_id WHERE ts.school_id=$1 ORDER BY ts.updated_at DESC`,[req.user.school_id]);res.json({submissions:rows});
});
app.patch('/api/school/mark-submissions/:id/review', schoolAdmin, async (req,res) => {
 const parsed=z.object({status:z.enum(['APPROVED','RETURNED']),reviewNote:z.string().max(500).optional().default('')}).safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'Choose approve or return and enter a valid note.'});const {rows}=await pool.query(`UPDATE teacher_assessment_submissions SET status=$1,reviewed_by=$2,reviewed_at=now(),review_note=$3,updated_at=now() WHERE id=$4 AND school_id=$5 AND status='SUBMITTED' RETURNING id,status,review_note AS "reviewNote"`,[parsed.data.status,req.user.id,parsed.data.reviewNote,req.params.id,req.user.school_id]);if(!rows[0])return res.status(404).json({error:'Submitted mark sheet not found or already reviewed.'});res.json({submission:rows[0]});
});

app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'Internal server error' }); });
const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`EDUCA SYSTEM API listening on ${port}`));
